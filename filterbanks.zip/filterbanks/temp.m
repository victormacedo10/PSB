	if length(x) > length(y)
		x1 = x;
		y1 = y;
		y1(length(x)) = 0;
	else
	end

